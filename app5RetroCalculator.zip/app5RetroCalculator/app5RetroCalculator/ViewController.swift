//
//  ViewController.swift
//  app5RetroCalculator
//
//  Created by Ojus Kapoor on 10/06/17.
//  Copyright © 2017 iOS Zen. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var outputLbl: UILabel!
    
    
    var btnSound = AVAudioPlayer()
    
    enum Operations: String {
        
        case Divide = "/"
        case Add = "+"
        case Multiply = "*"
        case Substract = "-"
        case Empty = "Empty"
    }
    
    var operatorType = Operations.Empty
    var runningNumber = ""
    var left = ""
    var right = ""
    var result = ""

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let path = Bundle.main.path(forResource: "btn", ofType: "wav")
        
        let soundURL = URL(fileURLWithPath: path!)
        
        do {
            try btnSound = AVAudioPlayer(contentsOf: soundURL)
            btnSound.prepareToPlay()
        } catch let err as NSError {
            print(err.debugDescription)
        }
    }
    
    
    
    @IBAction func numberPressed(sender: UIButton) {
        playSound()
        runningNumber += "\(sender.tag)"
        outputLbl.text = runningNumber
    }
    
    @IBAction func dividePressed(sender: AnyObject) {
        processOperations(operation: .Divide)
    }
    @IBAction func multiplyPressed(sender: AnyObject) {
        processOperations(operation: .Multiply)
    }
    @IBAction func addPressed(sender: AnyObject) {
        processOperations(operation: .Add)
    }
    @IBAction func subtractPressed(sender: AnyObject) {
        processOperations(operation: .Substract)
    }
    @IBAction func equalPresses(sender: AnyObject) {
       processOperations(operation: operatorType)
    }
 
    
    
    func playSound() {
        if btnSound.isPlaying {
            btnSound.stop()
        }
        btnSound.play()
    }
   
    
    func processOperations(operation: Operations) {
        playSound()
        if operatorType != Operations.Empty {
            if runningNumber != "" {
                right = runningNumber
                runningNumber = ""
                
                if operatorType == Operations.Multiply{
                    result = "\(Double(left)!*Double(right)!)"
                } else if operatorType == Operations.Divide {
                    result = "\(Double(left)!/Double(right)!)"
                } else if operatorType == Operations.Add {
                    result = "\(Double(left)!+Double(right)!)"
                } else if operatorType == Operations.Substract {
                    result = "\(Double(left)!-Double(right)!)"
                }
                left = result
                outputLbl.text = result
                
            }
            operatorType = operation
        } else {
            left = runningNumber
            runningNumber = ""
            operatorType = operation
        }
        
        
    }


}

